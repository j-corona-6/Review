import "./styles.css";
import {
  reactExtension,
  Banner,
  BlockStack,
  Text,
  useApi,
  useApplyAttributeChange,
  useInstructions,
  useTranslate,
  View,
  InlineLayout,
  Divider,
  Image,
  PaymentIcon,
} from "@shopify/ui-extensions-react/checkout";

// 1. Choose an extension target
export default reactExtension("purchase.checkout.payment-method-list.render-before", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { extension } = useApi();
  const instructions = useInstructions();
  const applyAttributeChange = useApplyAttributeChange();

  return (
    <>
      <BlockStack border={"dotted"} padding={"tight"}>
        <PaymentIcon name="shop-pay" />
      </BlockStack>
    </>
  );

}