import {
  reactExtension,
  Banner,
  BlockStack,
  Text,
  useApi,
  useApplyAttributeChange,
  useInstructions,
  useTranslate,
  View,
  InlineLayout,
  Divider,
  Image,
} from "@shopify/ui-extensions-react/checkout";

// 1. Choose an extension target
export default reactExtension("purchase.checkout.cart-line-list.render-after", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { extension } = useApi();
  const instructions = useInstructions();
  const applyAttributeChange = useApplyAttributeChange();

  const reviews = [
    { id: 1, author: 'Jane Doe', content: 'Great product!', rating: 5 },
    { id: 2, author: 'John Smith', content: 'Very satisfied.', rating: 4 },
  ];

  const fNames = [
    "Emilia",
    "Emma",
    "Sophia",
    "Hannah",
    "Mia",
    "Ella",
    "Mila",
    "Lina",
    "Lia",
    "Leni",
    "Clara",
    "Marie",
    "Lilly",
    "Noah",
    "Matteo",
    "Elias",
    "Leon",
    "Paul",
    "Theo",
    "Luca",
    "Finn",
    "Liam",
    "Emil",
    "Henry",
    "Felix",
    "Leo"
  ]

  const lNames = [
    "Müller",
    "Schmidt",
    "Schneider",
    "Fischer",
    "Weber",
    "Meyer",
    "Wagner",
    "Becker",
    "Schulz",
    "Hoffmann",
    "Koch",
    "Schwarz",
    "Richter",
    "Herrmann",
    "Schubert",
    "Baumann",
    "Wolf",
  ]

  const messages = [
    "Excellent service and fast shipping!",
    "The product quality exceeded my expectations. Highly recommend this store!",
    "Fantastic experience! The customer support team was very helpful and responsive. Will definitely shop here again.",
    "Great selection of products at reasonable prices. My order arrived on time and in perfect condition. Five stars!",
    "I am very satisfied with my purchase. The item was exactly as described and the checkout process was smooth and quick. I will definitely be shopping here again.",
    "This store has become my go-to for all my needs. The products are top-notch and the delivery is always prompt.",
    "Amazing quality and great value for money. The packaging was secure and the items arrived in perfect condition.",
    "Highly impressed with the speed of delivery and the quality of the products. Will definitely recommend to friends and family.",
    "The best online shopping experience I’ve had. The products are high quality and the customer service is exceptional",
    "I love this store! The variety of products is fantastic and the prices are unbeatable. Shipping was fast and hassle-free.",
    "I am very satisfied with my purchase. The item was exactly as described and the checkout process was smooth and quick. I will definitely be shopping here again.",
  ]
  const stars = [4, 5]

  function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }

  const reviewElements = reviews.map((review) => (
    <>
      <View key={review.id}>
        <InlineLayout
          spacing='base'
          columns={[100, 'fill', 50, 'auto']}
        >
          <Text>{'⭐'.repeat(stars[getRandomInt(stars.length)])}</Text>
          <Text size="small">26.01.2022</Text>
          <Image className="custom-image" source="https://cdn.shopify.com/s/files/1/0556/7958/2294/files/verified.png?v=1721413604" alt="verified" style={{ width: "20px", height: "20px" }} />

          <Text >Verifizierte Bewertung</Text>
        </InlineLayout>
        <Text size="medium">{messages[getRandomInt(messages.length)]}</Text>
        <Text emphasis="italic">{fNames[getRandomInt(fNames.length)]} {lNames[getRandomInt(lNames.length)]}</Text>
      </View>
      <Divider />
    </>
  ));

  // 3. Render a UI
  return (
    <>
      <BlockStack border={"dotted"} padding={"tight"}>
        <Banner title="Look at what our customers are saying">

        </Banner>
        {reviewElements}
      </BlockStack>
    </>
  );

}